package com.db1.conta.contaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContaApiApplication.class, args);
	}

}
